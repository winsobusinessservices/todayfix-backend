from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.utils.translation import gettext_lazy as _

from .managers import CustomUserManager


# class UserRole(models.TextChoices):
#     ADMIN = "ADMIN", "Admin"
#     BUSINESS = "BUSINESS", "Business"

class UserRole(models.TextChoices):
    ADMIN = "ADMIN", "Admin"
    USER = "USER", "User"
    BUSINESS = "BUSINESS", "Business"


class CustomUser(AbstractBaseUser, PermissionsMixin):
    name = models.CharField(max_length=150)

    email = models.EmailField(
        unique=True
    )

    phone = models.CharField(
        max_length=15,
        unique=True
    )

    # role = models.CharField(
    #     max_length=20,
    #     choices=UserRole.choices,
    #     default=UserRole.BUSINESS
    # )

    role = models.CharField(
        max_length=20,
        choices=UserRole.choices,
        default=UserRole.USER
    )

    business_registered = models.BooleanField(default=False)

    is_active = models.BooleanField(default=True)

    is_staff = models.BooleanField(default=False)

    date_joined = models.DateTimeField(auto_now_add=True)

    objects = CustomUserManager()

    USERNAME_FIELD = "email"

    REQUIRED_FIELDS = [
        "phone",
        "name",
    ]

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"

    def __str__(self):
        return f"{self.name} ({self.role})"