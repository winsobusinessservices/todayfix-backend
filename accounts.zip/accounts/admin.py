from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import CustomUser

from .forms import CustomUserCreationForm, CustomUserChangeForm


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    ordering = ("id",)

    add_form = CustomUserCreationForm
    form = CustomUserChangeForm

    list_display = (
        "id",
        "name",
        "email",
        "phone",
        "role",
        "is_active",
        "is_staff",
    )

    list_filter = (
        "role",
        "is_active",
        "is_staff",
    )

    search_fields = (
        "name",
        "email",
        "phone",
    )

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "email",
                    "phone",
                    "password",
                )
            },
        ),
        (
            "Personal Info",
            {
                "fields": (
                    "name",
                )
            },
        ),
        (
            "Permissions",
            {
                "fields": (
                    "role",
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                )
            },
        ),
    )

    add_fieldsets = (
    (
        None,
        {
            "classes": ("wide",),
            "fields": (
                "name",
                "email",
                "phone",
                "password1",
                "password2",
                "role",
                "is_active",
                "is_staff",
                "is_superuser",
            ),
        },
    ),
)
    